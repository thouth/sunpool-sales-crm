# LeadFlow CRM

A complete CRM app using Supabase for backend and Netlify for frontend deployment.